/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Models.Usuarios;

/**
 *
 * @author Soporte
 */
public interface I_Usuario {
    
    public boolean Login(String user,String pasw);
    
    
}
