/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Models.Asignaturas;

public interface I_Asignatura {
    public String getID();
    public String getNombre();
    public int getCreditos();
    public String GetPerfil();
    
    
}
