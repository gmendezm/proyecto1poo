package Models.Carreras;


public class Carrera {
    private String ID;
    private String nombre;

    public Carrera(String ID, String nombre) {
        this.ID = ID;
        this.nombre = nombre;
    }

    public String getID() {
        return ID;
    }

    
}
